import java.lang.reflect.Array;
import java.util.Scanner;
import java.util.*;
public class Tree_Word {

    private final static int RED = 0;
    private final static int BLACK = 1;

    public static mostTweetWrod[] mst = new mostTweetWrod [5];
    public static class mostTweetWrod {
        String word = "";
        int num = 0;

        mostTweetWrod(String word, int num)
        {
            this.word = word; this.num = num;
        }
    }

    public static class Node {

        String key = "";
        Tree_User.Node[] nickName = new Tree_User.Node[10000];
        String nameStr = "";
        int t = 0;
        int tweetNum = 0;
        int color = BLACK;

        Node left = nil, right = nil, parent = nil;

        Node(String key, String nickName) {
            this.key = key;
            this.nameStr = nickName;
        }
    }

    public final static Node nil = new Node("", "");
    public Node root = nil;

    public void printTree(Node node) {
        if (node == nil) {
            return;
        }
        printTree(node.left);
        System.out.print(((node.color==RED)?"Color: Red ":"Color: Black ")+"Key: "+node.key+" Parent: "+ node.tweetNum +"\n");
        printTree(node.right);
    }


    public Node findNode(Node findNode, Node node) {
        if (root == nil) {
            return null;
        }

        if (findNode.key.compareTo(node.key) < 0) {
            if (node.left != nil) {
                return findNode(findNode, node.left);
            }
        } else if (findNode.key.compareTo(node.key) > 0) {
            if (node.right != nil) {
                return findNode(findNode, node.right);
            }
        } else if (findNode.key.compareTo(node.key) == 0) {
            return node;
        }
        return null;
    }

    public Node tweetWord(Node findNode, Node node) {
        if (root == nil) {
            root = findNode;
            findNode.tweetNum++;

            int m = 0;
            int same = -1;
            int min = 99999;
            for(int i = 0; i < 5; i++) {

                if(mst[i].word.compareTo(findNode.key) == 0)
                    same = i;

                if (mst[i].num < min) {
                    min = mst[i].num;
                    m = i;
                }
            }
            if(same != -1) mst[same] = new mostTweetWrod(findNode.key, findNode.tweetNum);
            else if(mst[m].num < findNode.tweetNum) mst[m] = new mostTweetWrod(findNode.key, findNode.tweetNum);

            return findNode;
        } else if (findNode.key.compareTo(node.key)<0) {
            if (node.left != nil) {
                return tweetWord(findNode, node.left);
            }
            else {
                node.left = findNode;
                findNode.parent = node;
                findNode.color = RED;
                fixTree(findNode);
                findNode.tweetNum++;


                int m = 0;
                int same = -1;
                int min = 99999;
                for(int i = 0; i < 5; i++)
                {
                    if(mst[i].word.compareTo(findNode.key) == 0)
                        same = i;

                    if(mst[i].num < min)
                    {
                        min = mst[i].num;
                        m = i;
                    }
                }
                if(same != -1) mst[same] = new mostTweetWrod(findNode.key, findNode.tweetNum);
                else if(mst[m].num < findNode.tweetNum) mst[m] = new mostTweetWrod(findNode.key, findNode.tweetNum);

                return findNode;
            }
        } else if (findNode.key.compareTo(node.key)>0) {
            if (node.right != nil) {
                return tweetWord(findNode, node.right);
            }
            else {
                node.right = findNode;
                findNode.parent = node;
                findNode.color = RED;
                fixTree(findNode);
                findNode.tweetNum++;


                int m = 0;
                int same = -1;
                int min = 99999;
                for(int i = 0; i < 5; i++)
                {
                    if(mst[i].word.compareTo(findNode.key) == 0)
                        same = i;
                    if(mst[i].num < min)
                    {
                        min = mst[i].num;
                        m = i;
                    }
                }
                if(same != -1) mst[same] = new mostTweetWrod(findNode.key, findNode.tweetNum);
                else if(mst[m].num < findNode.tweetNum) mst[m] = new mostTweetWrod(findNode.key, findNode.tweetNum);

                return findNode;
            }
        } else if (findNode.key.compareTo(node.key) == 0) {
            node.tweetNum++;


            int m = 0;
            int same = -1;
            int min = 99999;
            for(int i = 0; i < 5; i++)
            {
                if(mst[i].word.compareTo(findNode.key) == 0)
                    same = i;
                if(mst[i].num < min)
                {
                    min = mst[i].num;
                    m = i;
                }
            }
            if(same != -1) mst[same] = new mostTweetWrod(node.key, node.tweetNum);
            else if(mst[m].num < node.tweetNum) mst[m] = new mostTweetWrod(node.key, node.tweetNum);

            return node;
        }
        return null;
    }

    //Takes as argument the newly inserted node
    private void fixTree(Node node) {
        while (node.parent.color == RED) {
            Node uncle = nil;
            if (node.parent == node.parent.parent.left) {
                uncle = node.parent.parent.right;

                if (uncle != nil && uncle.color == RED) {
                    node.parent.color = BLACK;
                    uncle.color = BLACK;
                    node.parent.parent.color = RED;
                    node = node.parent.parent;
                    continue;
                }
                if (node == node.parent.right) {
                    //Double rotation needed
                    node = node.parent;
                    rotateLeft(node);
                }
                node.parent.color = BLACK;
                node.parent.parent.color = RED;
                //if the "else if" code hasn't executed, this
                //is a case where we only need a single rotation 
                rotateRight(node.parent.parent);
            } else {
                uncle = node.parent.parent.left;
                if (uncle != nil && uncle.color == RED) {
                    node.parent.color = BLACK;
                    uncle.color = BLACK;
                    node.parent.parent.color = RED;
                    node = node.parent.parent;
                    continue;
                }
                if (node == node.parent.left) {
                    //Double rotation needed
                    node = node.parent;
                    rotateRight(node);
                }
                node.parent.color = BLACK;
                node.parent.parent.color = RED;
                //if the "else if" code hasn't executed, this
                //is a case where we only need a single rotation
                rotateLeft(node.parent.parent);
            }
        }
        root.color = BLACK;
    }

    void rotateLeft(Node node) {
        if (node.parent != nil) {
            if (node == node.parent.left) {
                node.parent.left = node.right;
            } else {
                node.parent.right = node.right;
            }
            node.right.parent = node.parent;
            node.parent = node.right;
            if (node.right.left != nil) {
                node.right.left.parent = node;
            }
            node.right = node.right.left;
            node.parent.left = node;
        } else {//Need to rotate root
            Node right = root.right;
            root.right = right.left;
            right.left.parent = root;
            root.parent = right;
            right.left = root;
            right.parent = nil;
            root = right;
        }
    }

    void rotateRight(Node node) {
        if (node.parent != nil) {
            if (node == node.parent.left) {
                node.parent.left = node.left;
            } else {
                node.parent.right = node.left;
            }

            node.left.parent = node.parent;
            node.parent = node.left;
            if (node.left.right != nil) {
                node.left.right.parent = node;
            }
            node.left = node.left.right;
            node.parent.right = node;
        } else {//Need to rotate root
            Node left = root.left;
            root.left = root.left.right;
            left.right.parent = root;
            root.parent = left;
            left.right = root;
            left.parent = nil;
            root = left;
        }
    }

    //Deletes whole tree
    void deleteTree(){
        root = nil;
    }

    //Deletion Code .

    //This operation doesn't care about the new Node's connections
    //with previous node's left and right. The caller has to take care
    //of that.
    void transplant(Node target, Node with){
        if(target.parent == nil){
            root = with;
        }else if(target == target.parent.left){
            target.parent.left = with;
        }else
            target.parent.right = with;
        with.parent = target.parent;
    }

    public mostTweetWrod min = new mostTweetWrod("", 0);
    void serchMosttweeted(Node node)
    {
        if(node == nil) return;
        boolean flag = true;
        for(int i = 0; i < 5; i++)
        {
            if(mst[i].word.compareTo(node.key) == 0)
                flag = false;
        }
        if(min.num < node.tweetNum && flag)
        {
            min.word = node.key;
            min.num = node.tweetNum;
        }
        serchMosttweeted(node.right);
        serchMosttweeted(node.left);

    }

    Node delete(Node z){
        if((z = findNode(z, root))==null)return null;

        for(int i = 0; i < z.t; i++)
        {
            z.nickName[i].tweetNum--;
            for(int j = 0; j < z.nickName[i].t; j++)
            {
                if(z.key.compareTo(z.nickName[i].word[j].key) == 0) {
                    for (int k = j; k < z.nickName[i].t - 1; k++) {
                        z.nickName[i].word[j] = z.nickName[i].word[j + 1];
                    }
                    z.nickName[i].t--;
                    break;
                }
            }
        }



        Node x;
        Node y = z; // temporary reference y
        int y_original_color = y.color;

        if(z.left == nil){
            x = z.right;
            transplant(z, z.right);
        }else if(z.right == nil){
            x = z.left;
            transplant(z, z.left);
        }else{
            y = treeMinimum(z.right);
            y_original_color = y.color;
            x = y.right;
            if(y.parent == z)
                x.parent = y;
            else{
                transplant(y, y.right);
                y.right = z.right;
                y.right.parent = y;
            }
            transplant(z, y);
            y.left = z.left;
            y.left.parent = y;
            y.color = z.color;
        }
        if(y_original_color==BLACK)
            deleteFixup(x);

        for(int i = 0; i < 5; i++)
        {
            if(mst[i].word.compareTo(z.key) == 0)
            {
                min.word = "";
                min.num = 0;
                serchMosttweeted(root);
                mst[i] = min;
            }
        }
        return z;
    }

    void deleteFixup(Node x){
        while(x!=root && x.color == BLACK){
            if(x == x.parent.left){
                Node w = x.parent.right;
                if(w.color == RED){
                    w.color = BLACK;
                    x.parent.color = RED;
                    rotateLeft(x.parent);
                    w = x.parent.right;
                }
                if(w.left.color == BLACK && w.right.color == BLACK){
                    w.color = RED;
                    x = x.parent;
                    continue;
                }
                else if(w.right.color == BLACK){
                    w.left.color = BLACK;
                    w.color = RED;
                    rotateRight(w);
                    w = x.parent.right;
                }
                if(w.right.color == RED){
                    w.color = x.parent.color;
                    x.parent.color = BLACK;
                    w.right.color = BLACK;
                    rotateLeft(x.parent);
                    x = root;
                }
            }else{
                Node w = x.parent.left;
                if(w.color == RED){
                    w.color = BLACK;
                    x.parent.color = RED;
                    rotateRight(x.parent);
                    w = x.parent.left;
                }
                if(w.right.color == BLACK && w.left.color == BLACK){
                    w.color = RED;
                    x = x.parent;
                    continue;
                }
                else if(w.left.color == BLACK){
                    w.right.color = BLACK;
                    w.color = RED;
                    rotateLeft(w);
                    w = x.parent.left;
                }
                if(w.left.color == RED){
                    w.color = x.parent.color;
                    x.parent.color = BLACK;
                    w.left.color = BLACK;
                    rotateRight(x.parent);
                    x = root;
                }
            }
        }
        x.color = BLACK;
    }

    Node treeMinimum(Node subTreeRoot){
        while(subTreeRoot.left!=nil){
            subTreeRoot = subTreeRoot.left;
        }
        return subTreeRoot;
    }
/*
    public void consoleUI() {
        Scanner scan = new Scanner(System.in);
        while (true) {
            System.out.println("\n1.- Add items\n"
                    + "2.- Delete items\n"
                    + "3.- Check items\n"
                    + "4.- Print tree\n"
                    + "5.- Delete tree\n");
            int choice = scan.nextInt();

            int item;
            Node node;
            switch (choice) {
                case 1:
                    item = scan.nextInt();
                    while (item != -999) {
                        node = new Node(item);
                        insert(node);
                        item = scan.nextInt();
                    }
                    printTree(root);
                    break;
                case 2:
                    item = scan.nextInt();
                    while (item != -999) {
                        node = new Node(item);
                        System.out.print("\nDeleting item " + item);
                        if (delete(node)) {
                            System.out.print(": deleted!");
                        } else {
                            System.out.print(": does not exist!");
                        }
                        item = scan.nextInt();
                    }
                    System.out.println();
                    printTree(root);
                    break;
                case 3:
                    item = scan.nextInt();
                    while (item != -999) {
                        node = new Node(item);
                        System.out.println((findNode(node, root) != null) ? "found" : "not found");
                        item = scan.nextInt();
                    }
                    break;
            }
        }
    }
    public static void main(String[] args) {
        RedBlackTree rbt = new RedBlackTree();
        rbt.consoleUI();
    }
    */
}