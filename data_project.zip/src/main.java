
import sun.reflect.generics.tree.Tree;

import java.util.*;
import java.io.*;



public class main {
    public static void main(String[] args) {

        Tree_User tree_User = new Tree_User();
        Tree_Word tree_Word = new Tree_Word();

        int totalUsers = 0;
        int totalFriendship = 0;
        int totalTweets = 0;
        for (int i = 0; i < 5; i++) {
            tree_Word.mst[i] = new Tree_Word.mostTweetWrod("", 0);
            tree_User.msu[i] = new Tree_User.Node("", "");
        }


        Scanner user = null;
        Scanner friend = null;
        Scanner word = null;
        try {
            user = new Scanner(new File("..\\data_project\\src\\user"));
            friend = new Scanner(new File("..\\data_project\\src\\friend"));
            word = new Scanner(new File("..\\data_project\\src\\word"));

            while (true) {
                String key = "";
                if (user.hasNextLine()) key = user.nextLine();
                else break;
                if (user.hasNextLine()) user.nextLine();
                String nickName = "";
                if (user.hasNextLine()) nickName = user.nextLine();
                else break;
                if (user.hasNextLine()) user.nextLine();

                Tree_User.Node node = new Tree_User.Node(key, nickName);
                tree_User.insert(node);

                totalUsers++;
            }

            while (true) {
                String friend00 = "";
                if (friend.hasNext()) friend00 = friend.next();
                else break;
                String friend01 = "";
                if (friend.hasNext()) friend01 = friend.next();
                else break;

                tree_User.increaseFriendNum(friend00, friend01, tree_User.root);
                tree_User.increaseFriendNum2(friend01, friend00, tree_User.root);

                totalFriendship++;
            }

            while (true) {
                String userName = "";
                if (word.hasNextLine()) userName = word.nextLine();
                else break;
                if (word.hasNextLine()) word.nextLine();
                String key = "";
                if (word.hasNextLine()) key = word.nextLine();
                else break;
                if (word.hasNextLine()) word.nextLine();

                Tree_Word.Node nodeWord = new Tree_Word.Node(key, userName);
                Tree_Word.Node node = tree_Word.tweetWord(nodeWord, tree_Word.root);

                node.nickName[node.t++] = tree_User.increaseTweetNum(userName, node, tree_User.root);

                totalTweets++;
            }
            tree_User.serchMosttweeted2(tree_User.root);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        Scanner sc = new Scanner(System.in);
        System.out.println("0. Read data files");
        System.out.println("1. display statistics");
        System.out.println("2. Top 5 most tweeted words");
        System.out.println("3. Top 5 most tweeted users");
        System.out.println("4. Find users who tweeted a word (e.g., �������롯)");
        System.out.println("5. Find all people who are friends of the above users");
        System.out.println("6. Delete all mentions of a word");
        System.out.println("7. Delete all users who mentioned a word");
        System.out.println("8. Find strongly connected components");
        System.out.println("9. Find shortest path from a given user");
        System.out.println("99. Quit");

        int menu = -1;

        Tree_Word.Node whoTweetWord = new Tree_Word.Node("", "");

        while (menu != 99) {

            System.out.print("\n\nSelect Menu: ");
            menu = sc.nextInt();
            switch (menu) {
                case 0:
                    System.out.println("Total users: " + totalUsers);
                    System.out.println("Total friendship records: " + totalFriendship);
                    System.out.println("Total tweets: " + totalTweets);
                    break;
                case 1:
                    System.out.println("Average number of friends: " + (float) (totalFriendship * 2) / (float) totalUsers);
                    System.out.println("Minimum friends: " + tree_User.minimum_friends);
                    System.out.println("Maximum number of friends: " + tree_User.maximum_friends);
                    System.out.println();
                    System.out.println("Average tweets per user: " + (float) totalTweets / (float) totalUsers);
                    System.out.println("Minimum tweets per user: " + tree_User.minimum_tweets);
                    System.out.println("Maximum tweets per user: " + tree_User.maximum_tweets);
                    break;
                case 2:
                    System.out.print("Top 5 most tweeted word: " + tree_Word.mst[0].word);
                    for (int i = 1; i < 5; i++) {
                        System.out.print(", " + tree_Word.mst[i].word);
                    }
                    System.out.println();
                    break;
                case 3:
                    System.out.print("Top 5 most tweeted users: " + tree_User.msu[0].key);
                    for (int i = 1; i < 5; i++) {
                        System.out.print(", " + tree_User.msu[i].key);
                    }
                    System.out.println();
                    break;
                case 4:
                    sc.nextLine();
                    System.out.print("Tweet word: ");
                    String str = sc.next();

                    whoTweetWord = tree_Word.findNode(new Tree_Word.Node(str, ""), tree_Word.root);
                    if(whoTweetWord.t != 0) System.out.print("Users who tweeted the word: " + whoTweetWord.nickName[0].key);
                    for (int i = 1; i < whoTweetWord.t; i++) {
                        System.out.print(", " + whoTweetWord.nickName[i].key);
                    }
                    break;
                case 5:
                    for (int i = 0; i < 5; i++) {
                        System.out.print("Friends of " + tree_User.msu[i].key + "(result of 3): ");
                        if(tree_User.msu[i].t!=0) System.out.print(tree_User.msu[i].friends[0].key);
                            for (int j = 1; j < tree_User.msu[i].t; j++) {
                            System.out.print(", " + tree_User.msu[i].friends[j].key);
                        }
                        System.out.println();
                    }
                    System.out.println();
                    Tree_User.Node node = new Tree_User.Node("", "");
                    for (int i = 0; i < whoTweetWord.t; i++) {
                        node = tree_User.findNode(new Tree_User.Node(whoTweetWord.nickName[i].key, ""), tree_User.root);
                        if(node.t != 0) System.out.print("Friends of " + node.key + "(result of 4): " + node.friends[0].key);
                        for (int j = 1; j < node.t; j++) {
                            System.out.print(", " + node.friends[j].key);
                        }
                        System.out.println();
                    }
                    break;
                case 6:
                    sc.nextLine();
                    System.out.print("Delete word: ");
                    String str2 = sc.next();

                    totalTweets = totalTweets - tree_Word.delete(new Tree_Word.Node(str2, "")).tweetNum;
                    break;
                case 7:
                    sc.nextLine();
                    System.out.print("Delete user with word: ");
                    String str3 = sc.next();
                    Tree_Word.Node tweetWord = tree_Word.findNode(new Tree_Word.Node(str3, ""), tree_Word.root);


                    for (int i = 0; i < tweetWord.t; i++) {
                        totalUsers--;
                        totalTweets = totalTweets - tweetWord.nickName[i].tweetNum;
                        totalFriendship = totalFriendship - tree_User.delete(tweetWord.nickName[i]).friendNum;
                    }
                    tree_Word.delete(tweetWord);

                    break;

                case 8:
                    System.out.print("user input: ");
                    String userInput = sc.next();
                    DFSvisitClear(tree_User.root);
                    for(int i = 0; i < 5; i ++)
                        maxStronglyConnectNum[i] = 0;
                    DFSStart(tree_User.findNode(new Tree_User.Node(userInput, ""), tree_User.root));
                    for(int i = 1; i < 6; i++)
                    {
                        int j = 0;
                        System.out.print("Strongly Connected Components " + i + ": ");
                        for(j = 0; j < maxStronglyConnectNum[i-1]; j++)
                        {
                            System.out.print(maxStronglyConnectComponent[i-1][j].key + " -> ");
                        }
                        if(maxStronglyConnectComponent[i-1][0] != null) System.out.print(maxStronglyConnectComponent[i-1][0].key);
                        System.out.println();
                    }
                    break;
                case 9:
                    System.out.print("user input: ");
                    String userInput2 = sc.next();
                    DFSvisitClear(tree_User.root);
                    for(int i = 0; i < 5; i++) {
                        weight[i] = 0;
                        t[i] = 0;
                    }
                    BFS(tree_User.findNode(new Tree_User.Node(userInput2, ""), tree_User.root), 0);
                    break;
                default:
                    System.out.print("Wrong Input\n");

            }
        }

    }
    public static int[] maxStronglyConnectNum = {0, 0, 0, 0, 0};
    public static Tree_User.Node[][] maxStronglyConnectComponent = new Tree_User.Node[5][1000000];

    public static Tree_User.Node[][] resultOfShortpath = new Tree_User.Node[5][100000];
    public static int[] t = {0, 0, 0, 0, 0};
    public static int[] weight = {0, 0, 0, 0, 0};
    public static void BFS(Tree_User.Node node, int num)
    {
        node.v = 1;
        num++;
        int min = 99999;
        Tree_User.Node minNode = null;
        int k = 0;
        for(int i = 0; i < 5; i++)
        {
            if(t[i] != 0)
            {
                for(int j = 0; j < resultOfShortpath[i][t[i]-1].t; j++)
                    if(min > resultOfShortpath[i][t[i]-1].friends[j].t + weight[i] && resultOfShortpath[i][t[i]-1].friends[j].v != 1)
                    {
                        min = resultOfShortpath[i][t[i]-1].friends[j].t + weight[i];
                        minNode = resultOfShortpath[i][t[i]-1].friends[j];
                        k = i;
                    }
            }
            else
            {
                for(int j = 0; j < node.t; j++)
                    if(min > node.friends[j].t && node.friends[j].v != 1)
                    {
                        min = node.friends[j].t;
                        minNode = node.friends[j];
                        k = i;
                    }
                break;
            }
        }
        minNode.v = 1;
        resultOfShortpath[k][t[k]++] = minNode;
        weight[k] += minNode.t;
        System.out.print("\nShortest path no." + num + ":" + node.key);
        for(int i = 0; i < t[k]; i++)
        {
            System.out.print(" -> " + resultOfShortpath[k][i].key);
        }
        if(num == 5)
            return;
        else
            BFS(node, num);
    }

    public static void DFSvisitClear(Tree_User.Node node)
    {
        if(node == Tree_User.nil) return;

        node.v = 0;
        DFSvisitClear(node.right);
        DFSvisitClear(node.left);
    }

    public static void DFSStart(Tree_User.Node node)
    {
        if(node.key == Tree_User.nil.key) return;

        Tree_User.Node[] stronglyConnextComponet = new Tree_User.Node[1000000];
        DFS(node, node, stronglyConnextComponet, 0);
    }


    public static void DFS(Tree_User.Node nodeFirst, Tree_User.Node node, Tree_User.Node[] arr, int num)
    {
        arr[num++] = node;
        node.v = 1;
        for(int i = 0; i < node.t; i++)
        {
            if(node.friends[i] == nodeFirst)
            {
                int min = 99999;
                int m = 0;
                for(int j = 0; j < 5; j++)
                {
                    if(maxStronglyConnectNum[j] < min) {
                        min = maxStronglyConnectNum[j];
                        m = j;
                    }
                }
                if(min < num)
                {
                    maxStronglyConnectNum[m] = num;
                    for(int j = 0; j < num; j++)
                        maxStronglyConnectComponent[m][j] = arr[j];
                }
            } else if(node.friends[i].v != 1){
                DFS(nodeFirst, node.friends[i], arr, num);
            }
        }
    }
}
