import java.util.Scanner;
import java.util.*;
public class Tree_User {

    private final static int RED = 0;
    private final static int BLACK = 1;
    public int minimum_friends = 999999;
    public int maximum_friends = -1;

    public int minimum_tweets = 999999;
    public int maximum_tweets = -1;

    public static Node[] msu = new Node [5];


    public static class Node {

        String key = "";
        String nickName = "";
        Node[] friends = new Node[10000];
        Node[] friends2 = new Node[10000];
        Tree_Word.Node[] word = new Tree_Word.Node[10000];
        int t = 0;
        int t2 = 0;
        int word_t = 0;
        int tweetNum = 0;
        int friendNum = 0;
        int color = BLACK;

        Node left = nil, right = nil, parent = nil;

        Node(String key, String nickName) {
            this.key = key;this.nickName = nickName;
        }
    }

    public final static Node nil = new Node("", "");
    public Node root = nil;

    public void printTree(Node node) {
        if (node == nil) {
            return;
        }
        printTree(node.left);
        System.out.print(((node.color==RED)?"Color: Red ":"Color: Black ")+"Key: "+node.key+" Parent: "+node.parent.key+"\n");
        printTree(node.right);
    }


    public Node findNode(Node findNode, Node node) {
        if (root == nil) {
            return null;
        }

        if (findNode.key.compareTo(node.key)<0) {
            if (node.left != nil) {
                return findNode(findNode, node.left);
            }
        } else if (findNode.key.compareTo(node.key)>0) {
            if (node.right != nil) {
                return findNode(findNode, node.right);
            }
        } else if (findNode.key.compareTo(node.key) == 0) {
            return node;
        }
        return null;
    }
    public Node increaseTweetNum(String str, Tree_Word.Node word, Node node) {
        if (str.compareTo(node.key)<0) {
            if (node.left != nil) {
                return increaseTweetNum(str, word, node.left);
            }
        } else if (str.compareTo(node.key)>0) {
            if (node.right != nil) {
                return increaseTweetNum(str, word, node.right);
            }
        } else if (str.compareTo(node.key) == 0) {
            node.tweetNum++;
            node.word[node.word_t++] = word;
            int m = -1;
            int same = -1;
            int min = 99999;
            for(int i = 0; i < 5; i++)
            {
                if(msu[i].key.compareTo(node.key) == 0) {
                    same = i;
                }

                if(msu[i].tweetNum < min)
                {
                    min = msu[i].tweetNum;
                    m = i;
                }
            }
            if(same != -1){
                msu[same] = node;
            }
            else if( m != -1 && msu[m].tweetNum < node.tweetNum){

                msu[m] = node;
            }

            if(node.tweetNum > maximum_tweets)
                maximum_tweets = node.tweetNum;
            if(node.tweetNum < minimum_tweets)
                minimum_tweets = node.tweetNum;

            return node;
        }
        return null;
    }
    public void increaseFriendNum(String str, String friend, Node node) {
        if (str.compareTo(node.key)<0) {
            if (node.left != nil) {
                increaseFriendNum(str, friend, node.left);
            }
        } else if (str.compareTo(node.key)>0) {
            if (node.right != nil) {
                increaseFriendNum(str, friend, node.right);
            }
        } else if (str.compareTo(node.key) == 0) {
            node.friendNum++;
            node.friends[node.t++] = findNode(new Node(friend, ""), root);
            if(node.friendNum > maximum_friends)
                maximum_friends = node.friendNum;
            if(node.friendNum < minimum_friends)
                minimum_friends = node.friendNum;
        }
        return;
    }
    public void increaseFriendNum2(String str, String friend, Node node) {
        if (str.compareTo(node.key)<0) {
            if (node.left != nil) {
                increaseFriendNum2(str, friend, node.left);
            }
        } else if (str.compareTo(node.key)>0) {
            if (node.right != nil) {
                increaseFriendNum2(str, friend, node.right);
            }
        } else if (str.compareTo(node.key) == 0) {
            node.friends2[node.t2++] = findNode(new Node(friend, ""), root);
        }
        return;
    }

    public void insert(Node node) {
        Node temp = root;
        if (root == nil) {
            root = node;
            node.color = BLACK;
            node.parent = nil;
        } else {
            node.color = RED;
            while (true) {
                if (node.key.compareTo(temp.key)<0) {
                    if (temp.left == nil) {
                        temp.left = node;
                        node.parent = temp;
                        break;
                    } else {
                        temp = temp.left;
                    }
                } else if (node.key.compareTo(temp.key)>0) {
                    if (temp.right == nil) {
                        temp.right = node;
                        node.parent = temp;
                        break;
                    } else {
                        temp = temp.right;
                    }
                }
            }
            fixTree(node);
        }
    }

    //Takes as argument the newly inserted node
    private void fixTree(Node node) {
        while (node.parent.color == RED) {
            Node uncle = nil;
            if (node.parent == node.parent.parent.left) {
                uncle = node.parent.parent.right;

                if (uncle != nil && uncle.color == RED) {
                    node.parent.color = BLACK;
                    uncle.color = BLACK;
                    node.parent.parent.color = RED;
                    node = node.parent.parent;
                    continue;
                }
                if (node == node.parent.right) {
                    //Double rotation needed
                    node = node.parent;
                    rotateLeft(node);
                }
                node.parent.color = BLACK;
                node.parent.parent.color = RED;
                //if the "else if" code hasn't executed, this
                //is a case where we only need a single rotation 
                rotateRight(node.parent.parent);
            } else {
                uncle = node.parent.parent.left;
                if (uncle != nil && uncle.color == RED) {
                    node.parent.color = BLACK;
                    uncle.color = BLACK;
                    node.parent.parent.color = RED;
                    node = node.parent.parent;
                    continue;
                }
                if (node == node.parent.left) {
                    //Double rotation needed
                    node = node.parent;
                    rotateRight(node);
                }
                node.parent.color = BLACK;
                node.parent.parent.color = RED;
                //if the "else if" code hasn't executed, this
                //is a case where we only need a single rotation
                rotateLeft(node.parent.parent);
            }
        }
        root.color = BLACK;
    }

    void rotateLeft(Node node) {
        if (node.parent != nil) {
            if (node == node.parent.left) {
                node.parent.left = node.right;
            } else {
                node.parent.right = node.right;
            }
            node.right.parent = node.parent;
            node.parent = node.right;
            if (node.right.left != nil) {
                node.right.left.parent = node;
            }
            node.right = node.right.left;
            node.parent.left = node;
        } else {//Need to rotate root
            Node right = root.right;
            root.right = right.left;
            right.left.parent = root;
            root.parent = right;
            right.left = root;
            right.parent = nil;
            root = right;
        }
    }

    void rotateRight(Node node) {
        if (node.parent != nil) {
            if (node == node.parent.left) {
                node.parent.left = node.left;
            } else {
                node.parent.right = node.left;
            }

            node.left.parent = node.parent;
            node.parent = node.left;
            if (node.left.right != nil) {
                node.left.right.parent = node;
            }
            node.left = node.left.right;
            node.parent.right = node;
        } else {//Need to rotate root
            Node left = root.left;
            root.left = root.left.right;
            left.right.parent = root;
            root.parent = left;
            left.right = root;
            left.parent = nil;
            root = left;
        }
    }

    //Deletes whole tree
    void deleteTree(){
        root = nil;
    }

    //Deletion Code .

    //This operation doesn't care about the new Node's connections
    //with previous node's left and right. The caller has to take care
    //of that.
    void transplant(Node target, Node with){
        if(target.parent == nil){
            root = with;
        }else if(target == target.parent.left){
            target.parent.left = with;
        }else
            target.parent.right = with;
        with.parent = target.parent;
    }

    public Node min;

    void serchMosttweeted2(Node node)
    {
        if(node == nil) return;
        if(maximum_tweets < node.tweetNum)
            maximum_tweets = node.tweetNum;
        if(minimum_tweets > node.tweetNum)
            minimum_tweets = node.tweetNum;
        if(maximum_friends < node.friendNum)
            maximum_friends = node.friendNum;
        if(minimum_tweets > node.friendNum)
            minimum_friends = node.friendNum;

        serchMosttweeted2(node.right);
        serchMosttweeted2(node.left);

    }

    void serchMosttweeted(Node node)
    {
        if(node == nil) return;
        boolean flag = true;
        if(maximum_tweets < node.tweetNum)
            maximum_tweets = node.tweetNum;
        if(minimum_tweets > node.tweetNum)
            minimum_tweets = node.tweetNum;
        if(maximum_friends < node.friendNum)
            maximum_friends = node.friendNum;
        if(minimum_tweets > node.friendNum)
            minimum_friends = node.friendNum;

        for(int i = 0; i < 5; i++)
        {
            if(msu[i].key.compareTo(node.key) == 0)
                flag = false;
        }
        if(min.tweetNum < node.tweetNum && flag)
        {
            min = node;
        }
        serchMosttweeted(node.right);
        serchMosttweeted(node.left);

    }

    Node delete(Node z){
        if((z = findNode(z, root))==null)return null;


        for(int i = 0; i < z.word_t; i++)
        {
            z.word[i].tweetNum--;
            for(int j = 0; j < z.word[i].t; j++)
            {
                if(z.word[i].nickName[j].key.compareTo(z.key) == 0) {
                    for (int k = j; k < z.word[i].t - 1; k++) {
                        z.word[i].nickName[k] = z.word[i].nickName[k + 1];
                    }
                    z.word[i].t--;
                }
            }
        }

        for(int i = 0; i < z.t; i++)
        {
            for(int j = 0; j < z.friends[i].t; j++)
            {
                if(z.friends[i].friends2[j] == z) {
                    for (int k = j; k < z.friends[i].t2 - 1; k++) {
                        z.friends[i].friends2[k] = z.friends[i].friends2[k + 1];
                    }
                    z.friends[i].t2--;
                    break;
                }
            }
        }

        for(int i = 0; i < z.t2; i++)
        {
            z.friends2[i].friendNum--;
            for(int j = 0; j < z.friends2[i].t; j++)
            {
                if(z.friends2[i].friends[j] == z) {
                    for (int k = j; k < z.friends2[i].t - 1; k++) {
                        z.friends2[i].friends[k] = z.friends2[i].friends[k + 1];
                    }
                    z.friends2[i].t--;
                    break;
                }
            }
        }


        Node x;
        Node y = z; // temporary reference y
        int y_original_color = y.color;

        if(z.left == nil){
            x = z.right;
            transplant(z, z.right);
        }else if(z.right == nil){
            x = z.left;
            transplant(z, z.left);
        }else{
            y = treeMinimum(z.right);
            y_original_color = y.color;
            x = y.right;
            if(y.parent == z)
                x.parent = y;
            else{
                transplant(y, y.right);
                y.right = z.right;
                y.right.parent = y;
            }
            transplant(z, y);
            y.left = z.left;
            y.left.parent = y;
            y.color = z.color;
        }
        if(y_original_color==BLACK)
            deleteFixup(x);

        for(int i = 0; i < 5; i++)
        {
            if(msu[i].key.compareTo(z.key) == 0)
            {
                maximum_friends = 0;
                maximum_tweets = 0;
                minimum_tweets = 99999;
                minimum_friends = 99999;
                msu[i] = nil;
                min = nil;
                serchMosttweeted(root);
                msu[i] = min;
            }
        }
        return z;
    }

    void deleteFixup(Node x){
        while(x!=root && x.color == BLACK){
            if(x == x.parent.left){
                Node w = x.parent.right;
                if(w.color == RED){
                    w.color = BLACK;
                    x.parent.color = RED;
                    rotateLeft(x.parent);
                    w = x.parent.right;
                }
                if(w.left.color == BLACK && w.right.color == BLACK){
                    w.color = RED;
                    x = x.parent;
                    continue;
                }
                else if(w.right.color == BLACK){
                    w.left.color = BLACK;
                    w.color = RED;
                    rotateRight(w);
                    w = x.parent.right;
                }
                if(w.right.color == RED){
                    w.color = x.parent.color;
                    x.parent.color = BLACK;
                    w.right.color = BLACK;
                    rotateLeft(x.parent);
                    x = root;
                }
            }else{
                Node w = x.parent.left;
                if(w.color == RED){
                    w.color = BLACK;
                    x.parent.color = RED;
                    rotateRight(x.parent);
                    w = x.parent.left;
                }
                if(w.right.color == BLACK && w.left.color == BLACK){
                    w.color = RED;
                    x = x.parent;
                    continue;
                }
                else if(w.left.color == BLACK){
                    w.right.color = BLACK;
                    w.color = RED;
                    rotateLeft(w);
                    w = x.parent.left;
                }
                if(w.left.color == RED){
                    w.color = x.parent.color;
                    x.parent.color = BLACK;
                    w.left.color = BLACK;
                    rotateRight(x.parent);
                    x = root;
                }
            }
        }
        x.color = BLACK;
    }

    Node treeMinimum(Node subTreeRoot){
        while(subTreeRoot.left!=nil){
            subTreeRoot = subTreeRoot.left;
        }
        return subTreeRoot;
    }
/*
    public void consoleUI() {
        Scanner scan = new Scanner(System.in);
        while (true) {
            System.out.println("\n1.- Add items\n"
                    + "2.- Delete items\n"
                    + "3.- Check items\n"
                    + "4.- Print tree\n"
                    + "5.- Delete tree\n");
            int choice = scan.nextInt();

            int item;
            Node node;
            switch (choice) {
                case 1:
                    item = scan.nextInt();
                    while (item != -999) {
                        node = new Node(item);
                        insert(node);
                        item = scan.nextInt();
                    }
                    printTree(root);
                    break;
                case 2:
                    item = scan.nextInt();
                    while (item != -999) {
                        node = new Node(item);
                        System.out.print("\nDeleting item " + item);
                        if (delete(node)) {
                            System.out.print(": deleted!");
                        } else {
                            System.out.print(": does not exist!");
                        }
                        item = scan.nextInt();
                    }
                    System.out.println();
                    printTree(root);
                    break;
                case 3:
                    item = scan.nextInt();
                    while (item != -999) {
                        node = new Node(item);
                        System.out.println((findNode(node, root) != null) ? "found" : "not found");
                        item = scan.nextInt();
                    }
                    break;
            }
        }
    }
    public static void main(String[] args) {
        RedBlackTree rbt = new RedBlackTree();
        rbt.consoleUI();
    }
    */
}